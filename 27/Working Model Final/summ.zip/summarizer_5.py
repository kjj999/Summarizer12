import os
import sys
os.system('ots '+sys.argv[1])
